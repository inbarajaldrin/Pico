#ifndef WRITE_TO_SD_H
#define WRITE_TO_SD_H

void write_to_sd();

#endif // WRITE_TO_SD_H
